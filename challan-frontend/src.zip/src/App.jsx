import { useState, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Header from "./components/Header";
import Login from "./components/Login";
import Home from "./pages/Home";
import AdminConfig from "./pages/AdminConfig";

import "./App.css";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  // ✅ Persist login across refresh
  useEffect(() => {
    const savedLogin = sessionStorage.getItem("loggedIn");
    if (savedLogin === "true") {
      setLoggedIn(true);
    }
  }, []);

  // 🔐 LOGIN GATE
  if (!loggedIn) {
    return (
      <Login
        onLogin={() => {
          sessionStorage.setItem("loggedIn", "true");
          setLoggedIn(true);
        }}
      />
    );
  }

  return (
    <div className="page">
      {/* COMMON GOVERNMENT HEADER */}
      <Header />

      {/* APPLICATION ROUTES */}
      <Routes>
        {/* Default Redirect */}
        <Route path="/" element={<Navigate to="/home" replace />} />

        {/* HOME / DASHBOARD */}
        <Route path="/home" element={<Home />} />

        {/* ADMIN CONFIGURATION */}
        <Route path="/admin" element={<AdminConfig />} />

        {/* FALLBACK */}
        <Route path="*" element={<Navigate to="/home" replace />} />
      </Routes>
    </div>
  );
}
