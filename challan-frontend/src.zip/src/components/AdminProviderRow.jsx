import { useState } from "react";
import API from "../api";

export default function AdminProviderRow({ provider }) {
  const [form, setForm] = useState({
    sid: "",
    token: "",
    caller_id: "",
  });

  const save = async () => {
    await API.post(`/admin/${provider.toLowerCase()}-config`, form, {
      headers: {
        "X-Admin-Key": "MH-GOV-SECURE-KEY"
      }
    });

    alert(`${provider} configuration saved`);
  };

  return (
    <div className="provider-row">
      <h3>{provider}</h3>

      <div className="form-grid">
        <input
          placeholder={`${provider} SID`}
          onChange={e => setForm({ ...form, sid: e.target.value })}
        />

        <input
          placeholder="API Key / Auth Token"
          onChange={e => setForm({ ...form, token: e.target.value })}
        />

        <input
          placeholder="XXXXXXXXXX"
          onChange={e => setForm({ ...form, caller_id: e.target.value })}
        />
      </div>

      <button className="primary-btn" onClick={save}>
        Activate {provider}
      </button>

      <hr />
    </div>
  );
}
