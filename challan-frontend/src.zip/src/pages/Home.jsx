import { useState } from "react";
import Announcement from "../components/Announcement";
import Dashboard from "../components/Dashboard";
import AddChallan from "../components/AddChallan";
import CsvUpload from "../components/CsvUpload";
import ChallanList from "../components/ChallanList";

export default function Home() {
  const [refresh, setRefresh] = useState(0);

  return (
    <>
      <Announcement />
      <Dashboard />

      {/* TWO COLUMN LAYOUT */}
      <div className="home-two-column">
        <div className="home-left">
          <AddChallan onSuccess={() => setRefresh(r => r + 1)} />
        </div>

        <div className="home-right">
          <CsvUpload onSuccess={() => setRefresh(r => r + 1)} />
        </div>
      </div>

      <ChallanList key={refresh} />
    </>
  );
}
