import { useState } from "react";
import API from "../api";

export default function AdminConfig() {
  const [twilio, setTwilio] = useState({});
  const [exotel, setExotel] = useState({});
  const [plivo, setPlivo] = useState({});

  const activate = async (provider, data) => {
    try {
      await API.post(`/admin/${provider}-config`, data);
      alert(`${provider.toUpperCase()} activated successfully`);
    } catch (err) {
      alert("Failed to activate provider");
    }
  };

  const ProviderBlock = ({ title, provider, data, setData }) => (
    <div className="provider-block">
      {/* PROVIDER HEADING */}
      <div className="provider-title">{title}</div>

      {/* INPUT ROW */}
      <div className="provider-input-row">
        <input
          type="text"
          placeholder={`${title} SID`}
          value={data.sid || ""}
          onChange={(e) => setData({ ...data, sid: e.target.value })}
        />

        <input
          type="password"
          placeholder="API Key / Auth Token"
          value={data.api_key || ""}
          onChange={(e) => setData({ ...data, api_key: e.target.value })}
        />

        <input
          type="text"
          placeholder="+91XXXXXXXXXX"
          value={data.caller_id || ""}
          onChange={(e) => setData({ ...data, caller_id: e.target.value })}
        />

        <button
          className="activate-btn"
          onClick={() => activate(provider, data)}
        >
          Activate
        </button>
      </div>
    </div>
  );

  return (
    <section className="card">
      <h2 className="section-title">
        Call Provider Configuration <span>(Admin)</span>
      </h2>

      <ProviderBlock
        title="Twilio"
        provider="twilio"
        data={twilio}
        setData={setTwilio}
      />

      <ProviderBlock
        title="Exotel"
        provider="exotel"
        data={exotel}
        setData={setExotel}
      />

      <ProviderBlock
        title="Plivo"
        provider="plivo"
        data={plivo}
        setData={setPlivo}
      />
    </section>
  );
}
